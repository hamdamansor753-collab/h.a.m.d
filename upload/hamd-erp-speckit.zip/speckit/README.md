# H.A.M.D ERP — Spec Kit

## ترتيب القراءة والتنفيذ
1. `foundation/00-vision.md`
2. `foundation/01-brand-identity.md`
3. `foundation/02-module-map.md`
4. `architecture/03-architecture-decisions.md` ← **الأهم، دستوري**
5. `architecture/04-data-model.md`
6. `architecture/05-security-baseline.md`
7. `ai-guide/10-coding-standards.md` ← يُرفَق مع كل prompt لـ z.ai
8. `ai-guide/11-phase-roadmap.md` ← ترتيب تنفيذ المراحل
9. `review/12-review-checklist.md` ← يُستخدم بعد كل تسليم كود

## طريقة الاستخدام مع z.ai / GLM
لكل مرحلة من `11-phase-roadmap.md`:
1. أرفق مع الـ prompt: `03-architecture-decisions.md` + `04-data-model.md` + `05-security-baseline.md` + `01-brand-identity.md` (لو فيه UI)
2. استخدم قالب الـ prompt الموجود في `10-coding-standards.md`
3. بعد استلام الكود، أرسله هنا للمراجعة مقابل `12-review-checklist.md`

## حالة المشروع الحالية
- [x] Spec Kit — الإصدار الأول مكتمل
- [ ] Phase 0 (Core) — لم يبدأ التنفيذ بعد
