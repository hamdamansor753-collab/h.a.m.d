# Prompt جاهز — Phase 8: SaaS Billing & Subscriptions

> نسخ ولصق في نفس مشروع `hamd-erp`. أرفق معه: `modules/saas-billing.md`

---

## السياق

المشروع فيه 6 موديولات تجارية + تصليب إنتاج (RLS حقيقي على PostgreSQL) + طبقة تخصيص (برندنج + قوالب أنشطة). الملف المرفق `modules/saas-billing.md` يصف نظام **اشتراكات المنصة نفسها** — إدارتك أنت لعملائك، مختلف عن كل الموديولات التجارية السابقة.

## المهمة

نفّذ حسب `modules/saas-billing.md`:

1. **نموذج البيانات**: `Plan`, `Subscription`, `SubscriptionStatus` enum, `PaymentRecord`
2. **دالة إنفاذ مركزية واحدة**: `requireActiveSubscription()` تُستدعى **مرة واحدة** جوه `withTenantContext` الموجودة من Phase 0 — **لا** تكرار الفحص في أي service تاني
3. **قاعدة GET/Write**: `SUSPENDED` تسمح بالقراءة، ترفض الكتابة بـ 402. `CANCELLED` ترفض كل حاجة.
4. **حدود الاستخدام**: فحص `maxUsers` في إنشاء مستخدم، فحص `maxInvoicesPerMonth` في `createInvoice` (عدّاد شهري بسيط)
5. **لوحة Super-Admin**: `/api/admin/tenants` (GET)، `/api/admin/payments` (POST — تسجيل دفعة يدوية تمدد `currentPeriodEnd`)
6. **صلاحية `platform:admin`**: **منفصلة تمامًا** عن RBAC العادي — اتصال DB مستقل يتجاوز الـ tenant scoping (زي الموصوف في `03-architecture-decisions.md` القرار الأول، "اتصال منفصل بصلاحيات خاصة" للعمليات عابرة الـ tenants)
7. **Seed**: خطة تجريبية افتراضية (`starter`)، كل tenant موجود يُنشأ له `Subscription` بحالة `ACTIVE` (البيانات التجريبية الحالية معفاة، مش تجريبية جديدة)

## تذكير بقواعد ثابتة
- كل الاختبارات 1-30 السابقة لازم تفضل PASS
- لا تكرار لمنطق فحص الاشتراك في أكثر من مكان — نقطة واحدة فقط

## اختبارات مطلوبة (فعلية)
1. Tenant جديد → `Subscription` بحالة `TRIALING` تلقائيًا
2. تسجيل دفعة يدوية → `currentPeriodEnd` يتمدد، الحالة `ACTIVE`
3. Tenant بحالة `SUSPENDED` (تُضبط يدويًا للاختبار) → GET ناجح، POST يرجع 402
4. تجاوز `maxUsers` → رفض إنشاء مستخدم جديد
5. مستخدم عادي (حتى admin tenant) يحاول يوصل `/api/admin/tenants` → رفض كامل (403)، بينما `platform:admin` يشوف كل الـ tenants
6. تأكيد كل الاختبارات 1-30 السابقة PASS

## المطلوب في الرد
1. الكود كاملًا
2. نتائج الاختبارات الستة فعليًا
3. **حدّث `worklog.md` بتفاصيل هذه المرحلة** (لوحظ إن المرحلة اللي فاتت ما اتسجلتش في السجل رغم تنفيذها فعليًا — تأكد من تسجيل هذه المرحلة كاملة)
4. أي افتراض يحتاج مراجعة
