# Prompt جاهز — Phase 7: Branding & Business Templates

> نسخ ولصق في نفس مشروع `hamd-erp` (بعد اكتمال الموديولات الست + Production Hardening، شغال على PostgreSQL/Supabase). أرفق معه: `modules/product-customization.md`

---

## السياق

المشروع فيه 6 موديولات كاملة + طبقة أمان مُصلَّبة (RLS حقيقي على PostgreSQL، ترقيم ذري، قفل مخزون)، 26 اختبار PASS. الملف المرفق `modules/product-customization.md` يصف **أول خطوة في "طبقة المنتج"**: تخصيص هوية العميل + قوالب أنشطة تجارية.

## المهمة

نفّذ حسب `modules/product-customization.md`:

1. **تعديل تراكمي على Tenant**: أضف `businessType String @default("general")` + علاقة `BrandSettings` — لا تلمس أي حقل موجود
2. **`BrandSettings` model**: كما هو موصوف
3. **دالة `getBusinessTypeSeedExtras(businessType)`**: ترجع حسابات إضافية حسب النشاط (الجدول في الملف المرفق) — تُستخدم فقط في onboarding tenant جديد، **لا تعديل على seed الاختبارات الحالي** (تأكد الـ 26 اختبار الموجودين لسه PASS)
4. **API**: `/api/tenant/branding` (GET/PATCH) — صلاحية `tenant:manage` جديدة لـ admin فقط
5. **واجهة إعدادات**: شاشة برندنج (شعار كـ URL، منتقي ألوان، نص أسفل الفاتورة) + معاينة فورية
6. **قاعدة صارمة**: لا `if (businessType === X)` في أي منطق تجاري (فواتير، مخزون، رواتب) — التخصيص بصري + بذرة حسابات فقط، مش فرع كود

## تذكير بقواعد ثابتة
- Tenant بدون `BrandSettings` يستمر بالعمل بألوان H.A.M.D الافتراضية بدون أي كسر
- كل الاختبارات 1-26 السابقة لازم تفضل PASS

## اختبارات مطلوبة (فعلية)
1. إنشاء tenant تجريبي جديد بـ `businessType=clinic` → التحقق إن شجرة حساباته فيها "رسوم استشارة" تلقائيًا (الأنواع الأخرى بدون هذا الحساب)
2. تحديث `BrandSettings` لـ tenant موجود → التحقق إن القيم المحدَّثة (شعار، ألوان) ترجع فعليًا من `/api/tenant/branding`
3. Tenant قديم بدون `BrandSettings` → لسه شغال طبيعي (لا كسر)
4. اختبار عزل tenant على `/api/tenant/branding` (PATCH من tenant تاني يُرفض)
5. تأكيد كل الاختبارات 1-26 السابقة PASS

## المطلوب في الرد
1. الكود كاملًا
2. نتائج الاختبارات الخمسة فعليًا
3. أي افتراض يحتاج مراجعة
