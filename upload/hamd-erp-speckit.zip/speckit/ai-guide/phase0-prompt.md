# Prompt جاهز — Phase 0: Core

> نسخ ولصق مباشر في z.ai (GLM). أرفق معه الملفات: 03-architecture-decisions.md, 04-data-model.md, 05-security-baseline.md, 01-brand-identity.md

---

## السياق

أنت تعمل على نظام **H.A.M.D ERP** — نظام SaaS متعدد المستأجرين (multi-tenant) موجّه للسوق العربي (مصر والخليج)، مبني بـ Next.js (App Router) + Prisma + PostgreSQL + shadcn/ui + Tailwind.

الملفات المرفقة معك تمثل قرارات معمارية **إلزامية وغير قابلة للتفاوض**:
- `03-architecture-decisions.md`: نموذج التعدد (RLS)، الستاك، RBAC، طبقة الضرائب
- `04-data-model.md`: سكيما Prisma الأساسية (Tenant, User, Role, Permission, Account, JournalEntry, Translation)
- `05-security-baseline.md`: قواعد أمان إلزامية
- `01-brand-identity.md`: هوية بصرية إلزامية (Cairo font, navy/cyan, RTL)

## المهمة: بناء Phase 0 (Core) بالكامل

نفّذ العناصر التالية بالترتيب:

### 1. الإعداد الأساسي
- مشروع Next.js (App Router, TypeScript) + Prisma + PostgreSQL
- تثبيت وتفعيل shadcn/ui + Tailwind مع دعم RTL كامل (استخدم CSS logical properties فقط — لا `left`/`right` مباشرة)

### 2. Schema أولي (Prisma)
طبّق الـ schema الموجود في `04-data-model.md` حرفيًا: Tenant, User, Role, Permission, UserRole, Account, AccountType enum, JournalEntry, JournalLine, Translation.

### 3. تفعيل RLS
- migration منفصلة تُفعّل `ENABLE ROW LEVEL SECURITY` وتنشئ policy على كل جدول به `tenantId`
- Prisma middleware يحقن `tenant_id` تلقائيًا من الجلسة الحالية في كل query (لا تعتمد على فلترة يدوية في كل route)

### 4. Auth
- تسجيل / تسجيل دخول، جلسات (اختر مكتبة مناسبة: NextAuth أو حل مماثل يدعم multi-tenancy)
- Middleware يحمي كل route محمي، ويرفض الطلب فورًا بدون جلسة صالحة

### 5. RBAC
- فحص الصلاحية (`permission:action`) في **service layer**، لا في الواجهة فقط
- بذرة أولية (seed) لأدوار أساسية: admin, accountant, viewer

### 6. i18n Engine
- نظام ترجمة يدعم `ar-EG`, `ar-SA`, `en` — كل نص UI عبر مفتاح ترجمة، بدون أي نص hardcoded
- Layout الأساسي يبدّل RTL/LTR تلقائيًا حسب اللغة المختارة
- تنسيق الأرقام/التواريخ عبر `Intl` حسب locale

### 7. Ledger الأساسي
- شجرة حسابات (Account) قابلة للتفريع
- إنشاء JournalEntry يدوي (endpoint API) مع **رفض إلزامي** إذا `SUM(debit) !== SUM(credit)`

### 8. اختبارات (الحد الأدنى المطلوب)
- اختبار: محاولة tenant A الوصول لبيانات tenant B عبر API يجب أن **تفشل** فعليًا (لا افتراض نظري)
- اختبار: إنشاء JournalEntry غير متوازن يجب أن يُرفَض

## قيود صارمة (لا تخالفها)
- كل API route يستخدم Prisma: `export const runtime = 'nodejs'` صريح
- كل مدخل مستخدم يُفحص بـ Zod قبل الوصول لطبقة الخدمة
- لا ألوان/نصوص hardcoded في أي كومبوننت
- لا وصول مباشر لـ Prisma من داخل route handler — فقط عبر service functions

## المطلوب في ردك
1. الكود كاملًا منظمًا في هيكل مجلدات واضح (`/core/...`)
2. قائمة الملفات المُنشأة
3. أي افتراض اتخذته لم يكن مذكورًا بالتفصيل في الملفات المرفقة (لمراجعته معي)
4. نتائج الاختبارات المذكورة في القسم 8
