# Prompt جاهز — Phase 3: POS

> نسخ ولصق في نفس مشروع `hamd-erp` (بعد Phase 0+1+2). أرفق معه: `modules/pos.md`

---

## السياق

المشروع عنده Phase 0 (Core) + Phase 1 (Accounting & Invoicing) + Phase 2 (Inventory & Purchasing) مكتملين ومُختبرين، بما فيهم `invoice.service.ts` (`postInvoice`) و `sales-movement.service.ts` (`recordSale`). الملف المرفق `modules/pos.md` يصف موديول **POS** بالتفصيل.

## المهمة

نفّذ موديول POS حسب `modules/pos.md` — **مبدأ أساسي: لا تُعِد كتابة أي منطق موجود**، POS طبقة تنسيق (orchestration) فوق الخدمات الحالية فقط:

1. **تعديل بسيط على Invoice**: أضف `channel` field + `InvoiceChannel` enum (`MANUAL` | `POS`) — تعديل تراكمي (additive)، لا تلمس أي حقل موجود
2. **`src/modules/pos/pos-sale.service.ts`**: دالة تنسيقية واحدة `posSale()` تنفّذ التسلسل الموصوف في `modules/pos.md` بالكامل داخل transaction واحدة atomic:
   - فحص كفاية المخزون لكل الأسطر **قبل** أي كتابة (رفض العملية كاملة لو أي سطر غير كافٍ)
   - إنشاء الفاتورة عبر الخدمة الموجودة من Phase 1 (بـ `channel: 'POS'`)
   - ترحيلها فورًا (`postInvoice`)
   - لكل سطر: استدعاء `recordSale` الموجودة من Phase 2
3. **صلاحية جديدة**: `pos:sell` + دور جديد `cashier` (وصول محدود: POS فقط، بدون تقارير/إعدادات) في seed
4. **API route**: `/api/pos/sale` (POST) — runtime nodejs + auth + permission(`pos:sell`) + Zod
5. **واجهة POS**: شاشة بحث سريع عن منتج + سلة + زر "إتمام البيع"، بهوية `01-brand-identity.md`

## تذكير بقواعد ثابتة (سارية دائمًا)
- كل عملية داخل `db.$transaction()` تتضمن `tenantId` صراحة (القاعدة من Phase 1)
- طريقة الدفع في هذه المرحلة: نقدي فقط (Cash) — لا تبني منطق دفع بالتقسيط الآن
- لا حساب ضريبة أو COGS مباشر خارج TaxProvider / sales-movement.service الموجودين

## اختبارات مطلوبة (فعلية، نفس المنهج)
1. بيع منتج عبر `/api/pos/sale` → تحقق: فاتورة `channel=POS` ظهرت، `StockLevel` نقصت بشكل صحيح، قيدين متوازنين (مبيعات + COGS) في `/api/journal`
2. محاولة بيع كمية أكبر من المتاح → رفض **قبل أي كتابة** — تحقق إن لا فاتورة ولا حركة مخزون أُنشئت (لا نتيجة جزئية)
3. اختبار عزل tenant على `/api/pos/sale`

## المطلوب في الرد
1. الكود كاملًا
2. نتائج الاختبارات الثلاثة فعليًا
3. تأكيد إنك لم تُعِد كتابة أي منطق من `invoice.service.ts` أو `sales-movement.service.ts` — فقط استدعيتهم
