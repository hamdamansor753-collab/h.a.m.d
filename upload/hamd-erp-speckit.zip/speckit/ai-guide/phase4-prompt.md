# Prompt جاهز — Phase 4: HR & Payroll

> نسخ ولصق في نفس مشروع `hamd-erp` (بعد Phase 0+1+2+3، بما فيها إصلاح الذرية). أرفق معه: `modules/hr.md`

---

## السياق

المشروع عنده Core + Accounting + Inventory + POS مكتملين ومُختبرين، بما فيهم نمط الذرية الصحيح (`db.$transaction()` شاملة + دوال بـ `tx` اختياري، زي `posSale()` بعد الإصلاح). الملف المرفق `modules/hr.md` يصف موديول **HR & Payroll**.

## المهمة

نفّذ الموديول حسب `modules/hr.md`:

1. **نموذج البيانات**: `Employee`, `EmployeeStatus`, `PayrollRun`, `PayrollStatus`, `PayrollLine`
2. **PayrollRuleProvider لمصر**: implementation في `src/core/payroll/` (نفس نمط `TaxProvider` من Phase 1 — registry + interface موحّد)، حساب مبسّط موضّح بوضوح في الكود إنه تقريبي مؤقت
3. **خدمة الرواتب** (`src/modules/hr/payroll.service.ts`):
   - CRUD أساسي للموظفين
   - `createPayrollRun(period)`: يجمع الموظفين النشطين، يحسب لكل واحد عبر Provider
   - `postPayrollRun(id)`: **transaction واحدة شاملة** (نفس نمط `posSale` بعد إصلاح Phase 3 — استخدم دوال بـ `tx` اختياري، لا تكرار منطق) تنشئ القيد المجمّع الواحد وتحدّث الحالة لـ POSTED
   - رفض أي تعديل بعد الترحيل
4. **صلاحيات دقيقة**: `hr:read`, `hr:manage`, `hr:salary:read` (منفصلة عن `hr:read` — تحكم فرز حقل الراتب في الاستجابة)، `payroll:run`
5. **API routes**: `/api/employees`, `/api/payroll-runs`, `/api/payroll-runs/:id/post` — runtime nodejs + auth + permission + Zod. لازم يكون فيه فرز صريح: لو المستخدم عنده `hr:read` بس بدون `hr:salary:read`، الاستجابة تُخفي حقول الراتب (لا رفض كامل للـ endpoint، بس حجب الحقل الحساس)
6. **واجهة UI**: قائمة موظفين + شاشة تشغيل رواتب (اختيار شهر → معاينة → ترحيل)، بهوية `01-brand-identity.md`

## تذكير بقواعد ثابتة (سارية دائمًا)
- أي عملية داخل `$transaction`: `tenantId` صريح (قاعدة Phase 1)
- الذرية الكاملة لـ `postPayrollRun`: فشل أي موظف = رجوع كل حاجة لورا (نفس منهج اختبار #12 في Phase 3)
- لا `nationalId` أو أرقام رواتب في أي رسالة خطأ أو log

## اختبارات مطلوبة (فعلية، نفس المنهج السابق)
1. تشغيل + ترحيل payroll run لشهر → قيد واحد متوازن بالمبالغ الصحيحة في `/api/journal`
2. محاولة قراءة قائمة الموظفين بصلاحية `hr:read` فقط → حقل الراتب مخفي/فارغ في الاستجابة
3. محاولة تعديل PayrollRun بعد POSTED → رفض
4. اختبار الفشل الجزئي: بيانات موظف غير صالحة وسط الدفعة → رفض الدفعة كاملة (نفس منطق اختبار #12)
5. اختبار عزل tenant

## المطلوب في الرد
1. الكود كاملًا
2. نتائج الاختبارات الخمسة فعليًا
3. أي افتراض يحتاج مراجعة (خصوصًا تفاصيل حساب الضريبة/التأمينات المبسّط المستخدم)
