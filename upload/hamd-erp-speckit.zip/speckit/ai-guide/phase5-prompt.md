# Prompt جاهز — Phase 5: CRM

> نسخ ولصق في نفس مشروع `hamd-erp` (بعد Phase 0+1+2+3+4). أرفق معه: `modules/crm.md`

---

## السياق

المشروع عنده Core + Accounting + Inventory + POS + HR/Payroll مكتملين ومُختبرين (17 اختبار PASS). الملف المرفق `modules/crm.md` يصف موديول **CRM** — آخر موديول في خارطة الطريق الأساسية.

## المهمة

نفّذ الموديول حسب `modules/crm.md`:

1. **نموذج البيانات**: `Customer`, `Appointment`, `AppointmentStatus`, `Reminder`, `ActivityLog`
2. **تعديل تراكمي على Invoice**: أضف `customerId String?` + العلاقة — **حقل اختياري**، لا تكسر أي فاتورة موجودة أو أي كود من Phase 1/3 (فحص: كل الاختبارات 1-17 لازم تفضل PASS بعد التعديل)
3. **خدمات** (`src/modules/crm/`):
   - `customer.service.ts`: CRUD
   - `appointment.service.ts`: حجز موعد + جدولة تذكير (`Reminder`) مرتبط
   - `activity-log.service.ts`: دالة داخلية `logActivity(tx, customerId, type, refId)` — **تُستدعى من داخل** `invoice.service.ts` (`createInvoice`, لو `customerId` موجود) و `appointment.service.ts`، **لا** endpoint عام لإنشائها يدويًا
   - تعديل تراكمي بسيط على `createInvoice` (من Phase 1/3): لو `customerId` تم تمريره، استدعِ `logActivity` كخطوة إضافية داخل نفس الـ transaction الموجودة — **لا تُعِد كتابة** منطق الفاتورة نفسه
4. **API routes**: `/api/customers`, `/api/appointments`, `/api/reminders/due` (GET — يرجّع `dueAt <= now() AND sent = false`)
5. **صلاحيات جديدة**: `crm:read`, `crm:manage`
6. **واجهة UI**: قائمة عملاء + شاشة حجز موعد + widget "تذكيرات مستحقة" في الـ dashboard

## تذكير بقواعد ثابتة (سارية دائمًا)
- أي عملية داخل `$transaction`: `tenantId` صريح
- **لا تلمس** منطق `postInvoice` أو حسابات الـ ledger — الإضافة الوحيدة هي استدعاء `logActivity` كخطوة جانبية، مش تعديل في القيد أو الفاتورة نفسها

## اختبارات مطلوبة (فعلية، نفس المنهج السابق)
1. إنشاء عميل → فاتورة بـ `customerId` → تحقق: `ActivityLog` سجل واحد نوعه `invoice_created` تلقائيًا
2. حجز موعد → تحقق: `ActivityLog` سجل `appointment_scheduled` + `Reminder` مرتبط
3. `/api/reminders/due` يرجّع فقط المواعيد المستحقة فعليًا (اختبار بموعد ماضي وموعد مستقبلي، يرجّع الماضي فقط)
4. فاتورة **بدون** `customerId` (بيع عابر) لسه تعمل بنجاح، بدون أي `ActivityLog`
5. اختبار عزل tenant على العملاء والمواعيد
6. **تأكيد الرجعية**: كل الاختبارات 1-17 السابقة لسه PASS بعد التعديلات

## المطلوب في الرد
1. الكود كاملًا
2. نتائج الاختبارات الستة فعليًا (خصوصًا رقم 6 — تأكيد عدم كسر أي شيء موجود)
3. أي افتراض يحتاج مراجعة
