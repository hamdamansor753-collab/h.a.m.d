# Prompt جاهز — Phase 1: Accounting & Invoicing

> نسخ ولصق مباشر في z.ai (GLM) داخل **نفس الجلسة/المشروع** بتاع Phase 0 (عشان يقدر يشوف الكود الموجود فعليًا). أرفق معه: `modules/accounting.md` (الملف الجديد)، بالإضافة لو أمكن لملف `03-architecture-decisions.md` مرة تانية كتذكير.

---

## قبل أي حاجة: إصلاح مطلوب من مراجعة Phase 0

قبل أي كود جديد في هذه المرحلة، نفّذ الإصلاح التالي على كود Phase 0 الموجود:

**المشكلة**: endpoint `/api/tests` بيسمح لأي مستخدم مسجّل دخول (حتى `viewer`) يشغّل اختبار يكشف معرف وكود حساب من tenant تاني عبر `dbRaw`، بدون فحص صلاحية مخصصة.

**المطلوب**:
1. أضف صلاحية جديدة `system:test` في seed الأدوار (تُمنح لدور `admin` فقط)
2. أضف `requirePermission('system:test')` في بداية `POST /api/tests` قبل أي منطق تاني
3. تأكد إن أي دور غير admin بيرجع 403 عند محاولة استدعاء الـ endpoint ده

---

## السياق

المشروع الحالي (`hamd-erp`) عنده Phase 0 (Core) مكتمل ومُختبر: Tenancy عبر Prisma Proxy fail-closed، Auth، RBAC service-layer، i18n (ar-EG/ar-SA/en)، Ledger بقاعدة القيد المزدوج المتوازن.

الملف المرفق `modules/accounting.md` يصف موديول **المحاسبة والفواتير** بالتفصيل الكامل.

## المهمة

نفّذ موديول Accounting & Invoicing بالكامل حسب `modules/accounting.md`:

1. **نموذج البيانات**: أضف `Invoice`, `InvoiceLine`, `InvoiceStatus` enum للـ Prisma schema الموجود (لا تلمس جداول Core الموجودة)
2. **TaxProvider لمصر**: implementation فعلي لـ interface الموجود في `src/core/ledger/tax-provider.ts` — حساب ضريبة 14% قابل للتخصيص لكل بند فاتورة، مُسجَّل في الـ registry
3. **خدمة الفواتير** (`src/core/modules/accounting/invoice.service.ts` أو مسار مشابه يحترم بنية الموديولات):
   - CRUD كامل لحالة DRAFT
   - `postInvoice(id)`: يحسب الضريبة عبر TaxProvider، يبني قيد متوازن، يستدعي `createJournalEntry` **الموجودة فعليًا من Phase 0** (لا تُعاد كتابتها)، ويحدّث حالة الفاتورة لـ POSTED في transaction واحدة
   - رفض أي تعديل/حذف على فاتورة POSTED
   - `voidInvoice(id)`: قيد عكسي، لا حذف
4. **API routes**: `/api/invoices` (GET/POST)، `/api/invoices/:id` (GET/PATCH — DRAFT فقط)، `/api/invoices/:id/post`، `/api/invoices/:id/void` — كل واحد: runtime nodejs + auth + permission + Zod
5. **صلاحيات جديدة**: أضف للـ seed: `invoice:create`, `invoice:read`, `invoice:post`, `invoice:void`
6. **تقرير قائمة دخل مبسّط**: `/api/reports/income-statement` — يُحسب من `JournalLine` مباشرة (SUM حسب AccountType)، لا جدول منفصل
7. **واجهة UI بسيطة**: قائمة فواتير + نموذج إنشاء/تعديل + زر ترحيل، بنفس هوية `01-brand-identity.md`

## قيود صارمة (من `05-security-baseline.md`، سارية دائمًا)
- كل route: `export const runtime = 'nodejs'` + auth + permission check + Zod
- لا حساب ضريبة مباشر خارج TaxProvider
- لا تعديل مباشر لـ JournalEntry أو JournalLine خارج الـ ledger services الموجودة
- كل نص UI عبر i18n key

## اختبارات مطلوبة (نفس منهج Phase 0 — فعلية لا نظرية)
1. إنشاء فاتورة Draft → تعديل → ترحيل → التحقق إن `JournalEntry` الناتج متوازن فعليًا في `/api/journal`
2. محاولة تعديل فاتورة POSTED → رفض فعلي (401/403/400 حسب الحالة)
3. اختبار عزل tenant على الفواتير (نفس منطق اختبار Phase 0: tenant A لا يقدر يقرأ/يعدّل فاتورة tenant B)

## المطلوب في الرد
1. الكود كاملًا
2. تأكيد إصلاح `/api/tests` (القسم الأول)
3. نتائج الاختبارات الثلاثة أعلاه فعليًا (لا افتراضًا)
4. أي افتراض اتخذته يحتاج مراجعة معي
