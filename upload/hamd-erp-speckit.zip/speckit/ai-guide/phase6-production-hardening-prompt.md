# Prompt جاهز — Production Hardening

> نسخ ولصق في نفس مشروع `hamd-erp` (بعد اكتمال الموديولات الست). أرفق معه: `modules/production-hardening.md`، وتأكد إن Docker متاح في بيئتك لتشغيل PostgreSQL محليًا (اذكر لـ GLM لو مش متاح، وهيقترح بديل).

---

## السياق

المشروع فيه 6 موديولات كاملة (Core, Accounting, Inventory, POS, HR, CRM)، 22 اختبار أمان/ذرية PASS، لكن شغال على SQLite dev — والملف المرفق `modules/production-hardening.md` يصف 4 بنود إلزامية قبل أي استخدام إنتاجي فعلي.

## المهمة

نفّذ البنود الأربعة بالكامل حسب `modules/production-hardening.md`:

### 1. الترحيل لـ PostgreSQL + تفعيل RLS الفعلي
- غيّر `provider` في schema.prisma، شغّل PostgreSQL (Docker محلي)، طبّق الـ migrations
- نفّذ `prisma/sql/tenant_rls_postgres.sql` فعليًا على القاعدة
- اختبار حاسم: عطّل middleware العزل مؤقتًا للاختبار، تأكد إن RLS نفسه على مستوى القاعدة بيرفض query عابر لـ tenant، وثّق النتيجة، أعد التفعيل

### 2. ترقيم تسلسلي مقفول
- أضف `SequenceCounter` model
- دالة `getNextSequenceValue(tx, tenantId, sequenceKey)` بـ atomic `UPDATE ... RETURNING`
- استبدل `nextInvoiceNumber` و `nextPurchaseOrderNumber` الحاليين بيها (استبدال، لا تكرار)

### 3. قفل عملية المخزون
- استبدل check-then-write في `recordMovement` بـ atomic `UPDATE ... WHERE quantity >= X RETURNING` واحدة (استخدم `$queryRaw` أو ما يكافئه في Prisma لو احتجت SQL مباشر)

### 4. دقة ضريبة الرواتب
- أعد بناء `EgyptPayrollRuleProvider` بالشرائح السبع والتأمينات المذكورة في `modules/production-hardening.md` بالتفصيل
- الأرقام في ثوابت منفصلة قابلة للتعديل، مع تعليق يوجّه للتحقق مع محاسب قانوني

## قيود صارمة
- **لا تغيير في منطق الـ ledger أو الفواتير أو المخزون نفسه** — فقط الآلية التقنية للترقيم والقفل
- كل الاختبارات 1-22 الموجودة لازم تفضل PASS بعد الترحيل لـ PostgreSQL (لا استثناء)

## اختبارات مطلوبة (فعلية)
1. إثبات RLS الحقيقي (middleware معطّل، RLS بيرفض من القاعدة نفسها)
2. اختبار تزامن: طلبين متزامنين لنفس رقم فاتورة/أمر شراء → أرقام مختلفة بدون تعارض
3. اختبار تزامن: بيعتين متزامنتين تتجاوز مجتمعهم المخزون المتاح → واحدة تنجح فقط
4. حساب ضريبة صحيح لراتب عيّنة، مقارنة يدوية بالشرائح
5. تأكيد كل الاختبارات 1-22 السابقة PASS على PostgreSQL

## المطلوب في الرد
1. الكود كاملًا + أي migration جديد
2. نتائج الاختبارات الخمسة فعليًا
3. أي عائق واجهته في تشغيل PostgreSQL (لو مفيش Docker متاح، وضّح الحل البديل اللي استخدمته)
