# Prompt جاهز — Phase 2: Inventory & Purchasing

> نسخ ولصق في نفس مشروع `hamd-erp` (بعد Phase 0 + Phase 1). أرفق معه: `modules/inventory.md`

---

## السياق

المشروع عنده Phase 0 (Core: tenancy/auth/RBAC/i18n/ledger) و Phase 1 (Accounting & Invoicing) مكتملتين ومُختبرتين. الملف المرفق `modules/inventory.md` يصف موديول **المخازن والمشتريات** بالتفصيل الكامل.

## المهمة

نفّذ موديول Inventory & Purchasing بالكامل حسب `modules/inventory.md`:

1. **نموذج البيانات**: أضف `Warehouse`, `Product`, `StockLevel`, `StockMovement`, `StockMovementType` enum, `PurchaseOrder`, `PurchaseOrderLine`, `PurchaseOrderStatus` enum — لا تلمس جداول Core أو Accounting الموجودة
2. **قاعدة صارمة**: لا تحديث مباشر لـ `StockLevel.quantity` من أي مكان — فقط عبر إنشاء `StockMovement` والتحديث التابع له في نفس transaction
3. **خدمات** (`src/modules/inventory/`):
   - `product.service.ts`, `warehouse.service.ts`: CRUD أساسي
   - `stock-movement.service.ts`: الدالة الوحيدة المسموح لها تغيير `StockLevel`
   - `purchase-order.service.ts`: CRUD لـ DRAFT + `receivePurchaseOrder(id)` (استلام كامل الأمر: StockMovement لكل سطر + قيد محاسبي متوازن + تحديث costPrice، كل ده في transaction واحدة)
   - `sales-movement.service.ts`: دالة `recordSale(productId, warehouseId, quantity)` تُستدعى مستقبلًا من POS — ترفض لو الكمية غير كافية، وتنشئ قيد COGS
4. **API routes**: `/api/warehouses`, `/api/products`, `/api/purchase-orders`, `/api/purchase-orders/:id/receive` — كل واحد: runtime nodejs + auth + permission + Zod
5. **صلاحيات جديدة**: `inventory:read`, `inventory:adjust`, `purchase:create`, `purchase:receive` — تُضاف للـ seed بنفس منطق sync الموجود (الحرص على ربط الصلاحيات الجديدة بالأدوار الموجودة، مش بس إنشاءها)
6. **واجهة UI بسيطة**: قائمة منتجات + مخازن + شاشة أوامر شراء (إنشاء/استلام)، بهوية `01-brand-identity.md`

## تذكير بقواعد ثابتة (سارية دائمًا، من `05-security-baseline.md`)
- كل route: runtime nodejs + auth + permission + Zod
- لا حساب محاسبي مباشر خارج `createJournalEntryOn` الموجودة
- **تذكير حرج من Phase 1**: أي عملية داخل `db.$transaction()` لازم تتضمن `tenantId` صراحة في الـ where/data — الـ transaction client لا يحمل middleware العزل التلقائي

## اختبارات مطلوبة (فعلية لا نظرية، نفس منهج الفازات السابقة)
1. إنشاء أمر شراء → استلامه → تحقق: `StockLevel` زادت بالكمية الصحيحة + قيد محاسبي متوازن ظهر في `/api/journal` + `StockMovement` واحد بالضبط لكل سطر
2. محاولة `recordSale` بكمية أكبر من المتاح → رفض فعلي، `StockLevel` لم تتغير
3. اختبار عزل tenant على المنتجات/المخازن/أوامر الشراء

## المطلوب في الرد
1. الكود كاملًا
2. نتائج الاختبارات الثلاثة فعليًا
3. أي افتراض يحتاج مراجعة معي (خصوصًا طريقة حساب متوسط التكلفة — الـ spec طلب متوسط مرجّح مبسّط، وضّح إزاي طبّقته بالتحديد)
