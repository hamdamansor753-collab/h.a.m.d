# 11 - خارطة طريق المراحل (Phase Roadmap)

## Phase 0 — Core (لا يبدأ أي موديول تجاري قبل اكتمالها)
- [ ] إعداد Next.js + Prisma + PostgreSQL
- [ ] نموذج Tenant / User / Role / Permission
- [ ] Auth (تسجيل دخول، جلسات، middleware حماية الـ routes)
- [ ] تفعيل RLS على مستوى PostgreSQL + Prisma middleware لحقن tenantId
- [ ] i18n engine (جداول Translation + دعم ar-EG / ar-SA / en) + RTL/LTR كامل في UI shell
- [ ] Ledger: Account (شجرة حسابات) + JournalEntry + JournalLine + قاعدة توازن القيد
- [ ] TaxProvider interface (بدون أي implementation فعلي لدولة بعد — فقط الواجهة)
- [ ] اختبارات tenant-isolation أساسية (محاولة اختراق tenant لأخرى تفشل)

**معيار الإتمام**: يمكن إنشاء tenant جديد، مستخدم، تسجيل قيد محاسبي يدوي متوازن، وتبديل اللغة/الاتجاه في الواجهة بالكامل.

---

## Phase 1 — Accounting & Invoicing
- [ ] TaxProvider لمصر (ETA) كأول implementation
- [ ] نموذج Invoice / InvoiceLine مرتبط بالـ Ledger تلقائيًا
- [ ] تقارير مالية أساسية (قائمة دخل، ميزانية) مبنية من الـ Ledger مباشرة

## Phase 2 — Inventory & Purchasing
- [ ] المنتجات، المخازن، حركات المخزون
- [ ] الربط التلقائي بالـ Ledger عند البيع/الشراء (تكلفة البضاعة المباعة)

## Phase 3 — POS
- [ ] واجهة نقاط بيع سريعة، تعتمد على Inventory + Accounting

## Phase 4 — HR & Payroll
- [ ] نموذج موظفين، حضور، رواتب مصرية أولًا (قابلة للتوسع خليجيًا)

## Phase 5 — CRM
- [ ] عملاء، مواعيد، تذكيرات

---

## قاعدة الانتقال بين المراحل
لا تبدأ مرحلة جديدة إلا بعد:
1. مراجعة كود المرحلة السابقة بالكامل عبر `12-review-checklist.md`
2. إغلاق كل الملاحظات الحرجة (Critical) من المراجعة
